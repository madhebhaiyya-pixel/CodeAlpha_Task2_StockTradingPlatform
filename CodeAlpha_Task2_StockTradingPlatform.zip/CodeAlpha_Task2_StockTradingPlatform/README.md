# CodeAlpha Task 2: Stock Trading Platform

A beginner-friendly Java console application that simulates stock trading. This is an educational project and does not connect to a real stock market.

## Features
- Display sample market stocks and prices
- Buy stocks using a simulated cash balance
- Sell only stocks that are owned
- View portfolio holdings and total portfolio value
- View transaction history with date and time
- Object-oriented design using `Stock`, `Portfolio`, `Transaction`, and `StockTradingPlatform`
- Input validation for invalid quantities and menu choices

## Requirements
- Java JDK 17 or later (Java 21 is also supported)
- Eclipse, IntelliJ IDEA, or a terminal

## Run in Eclipse
1. Extract the ZIP file.
2. Open Eclipse and select **File > New > Java Project**.
3. Name the project `CodeAlpha_Task2_StockTradingPlatform`.
4. Copy all four `.java` files from the `src` folder into the project's `src` folder.
5. Open `StockTradingPlatform.java`.
6. Click **Run**.

## Run using terminal
Open a terminal inside the extracted project folder and run:

```bash
javac -d out src/*.java
java -cp out StockTradingPlatform
```

## Sample stock data
| Symbol | Company | Sample price |
|---|---|---:|
| TCS | Tata Consultancy | Rs. 3500.00 |
| INFY | Infosys | Rs. 1800.00 |
| WIPRO | Wipro | Rs. 500.00 |
| RELI | Reliance Industries | Rs. 2900.00 |
| HDFC | HDFC Bank | Rs. 1650.00 |

Prices are fictional sample values for demonstration and are not live market prices.

## Notes
- Starting simulated cash balance: Rs. 100,000.
- Portfolio data is kept in memory while the program is running. It resets when the program exits.
- This version does not use a database or file persistence; those are optional in the task.
