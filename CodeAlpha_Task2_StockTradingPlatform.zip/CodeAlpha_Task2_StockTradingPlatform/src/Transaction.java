import java.time.LocalDateTime;
import java.time.format.DateTimeFormatter;

public class Transaction {
    private final String type;
    private final String symbol;
    private final int quantity;
    private final double price;
    private final LocalDateTime time;

    public Transaction(String type, String symbol, int quantity, double price) {
        this.type = type;
        this.symbol = symbol;
        this.quantity = quantity;
        this.price = price;
        this.time = LocalDateTime.now();
    }

    @Override
    public String toString() {
        return String.format("%s | %-4s | %s | Qty: %d | Price: Rs. %.2f | Total: Rs. %.2f",
                time.format(DateTimeFormatter.ofPattern("dd-MM-yyyy HH:mm:ss")),
                type, symbol, quantity, price, quantity * price);
    }
}
