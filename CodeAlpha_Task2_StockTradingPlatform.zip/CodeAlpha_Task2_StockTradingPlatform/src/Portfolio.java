import java.util.LinkedHashMap;
import java.util.Map;

public class Portfolio {
    private final Map<String, Integer> holdings = new LinkedHashMap<>();
    private double cashBalance;

    public Portfolio(double startingBalance) {
        cashBalance = startingBalance;
    }

    public double getCashBalance() { return cashBalance; }

    public int getQuantity(String symbol) {
        return holdings.getOrDefault(symbol, 0);
    }

    public boolean buy(Stock stock, int quantity) {
        if (quantity <= 0) return false;
        double total = stock.getPrice() * quantity;
        if (total > cashBalance) return false;

        cashBalance -= total;
        holdings.put(stock.getSymbol(), getQuantity(stock.getSymbol()) + quantity);
        return true;
    }

    public boolean sell(Stock stock, int quantity) {
        if (quantity <= 0 || getQuantity(stock.getSymbol()) < quantity) return false;

        cashBalance += stock.getPrice() * quantity;
        int remaining = getQuantity(stock.getSymbol()) - quantity;
        if (remaining == 0) holdings.remove(stock.getSymbol());
        else holdings.put(stock.getSymbol(), remaining);
        return true;
    }

    public void display(Map<String, Stock> market) {
        System.out.println("\n========== MY PORTFOLIO ==========");
        System.out.printf("Available cash: Rs. %.2f%n", cashBalance);
        if (holdings.isEmpty()) {
            System.out.println("No stocks owned yet.");
            System.out.println("===================================\n");
            return;
        }

        double marketValue = 0;
        System.out.printf("%-8s %-22s %-10s %-15s%n", "Symbol", "Company", "Quantity", "Market Value");
        for (Map.Entry<String, Integer> entry : holdings.entrySet()) {
            Stock stock = market.get(entry.getKey());
            int quantity = entry.getValue();
            double value = stock.getPrice() * quantity;
            marketValue += value;
            System.out.printf("%-8s %-22s %-10d Rs. %-12.2f%n",
                    stock.getSymbol(), stock.getCompanyName(), quantity, value);
        }
        System.out.printf("Total stock market value: Rs. %.2f%n", marketValue);
        System.out.printf("Total portfolio value: Rs. %.2f%n", cashBalance + marketValue);
        System.out.println("Note: Profit/Loss versus the initial balance is not calculated in this basic simulator.");
        System.out.println("===================================\n");
    }
}
