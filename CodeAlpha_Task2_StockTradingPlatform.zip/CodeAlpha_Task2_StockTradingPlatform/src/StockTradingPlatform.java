import java.util.ArrayList;
import java.util.LinkedHashMap;
import java.util.List;
import java.util.Map;
import java.util.Scanner;

public class StockTradingPlatform {
    private static final Scanner scanner = new Scanner(System.in);
    private static final Map<String, Stock> market = new LinkedHashMap<>();
    private static final List<Transaction> transactions = new ArrayList<>();
    private static final double STARTING_BALANCE = 100000.00;
    private static final Portfolio portfolio = new Portfolio(STARTING_BALANCE);

    public static void main(String[] args) {
        addSampleStocks();

        System.out.println("========================================");
        System.out.println("       STOCK TRADING PLATFORM");
        System.out.println("       Educational Simulation Only");
        System.out.println("========================================");

        boolean running = true;
        while (running) {
            showMenu();
            int choice = readInt("Enter your choice: ");

            switch (choice) {
                case 1 -> displayMarket();
                case 2 -> buyStock();
                case 3 -> sellStock();
                case 4 -> portfolio.display(market);
                case 5 -> displayTransactions();
                case 6 -> running = false;
                default -> System.out.println("Invalid choice. Please enter 1 to 6.");
            }
        }

        System.out.println("Thank you for using Stock Trading Platform!");
        scanner.close();
    }

    private static void addSampleStocks() {
        market.put("TCS", new Stock("TCS", "Tata Consultancy", 3500.00));
        market.put("INFY", new Stock("INFY", "Infosys", 1800.00));
        market.put("WIPRO", new Stock("WIPRO", "Wipro", 500.00));
        market.put("RELI", new Stock("RELI", "Reliance Industries", 2900.00));
        market.put("HDFC", new Stock("HDFC", "HDFC Bank", 1650.00));
    }

    private static void showMenu() {
        System.out.println("\n--------------- MAIN MENU ---------------");
        System.out.println("1. View Market Stocks");
        System.out.println("2. Buy Stocks");
        System.out.println("3. Sell Stocks");
        System.out.println("4. View Portfolio");
        System.out.println("5. View Transaction History");
        System.out.println("6. Exit");
    }

    private static void displayMarket() {
        System.out.println("\n================ MARKET DATA ================");
        System.out.printf("%-8s %-22s %s%n", "Symbol", "Company", "Price");
        for (Stock stock : market.values()) System.out.println(stock);
        System.out.println("Prices are sample values for this educational project.");
        System.out.println("=============================================");
    }

    private static void buyStock() {
        displayMarket();
        String symbol = readSymbol("Enter stock symbol to buy (e.g. TCS): ");
        Stock stock = market.get(symbol);
        if (stock == null) {
            System.out.println("Stock symbol not found.");
            return;
        }

        int quantity = readInt("Enter quantity: ");
        if (quantity <= 0) {
            System.out.println("Quantity must be greater than zero.");
            return;
        }

        double total = stock.getPrice() * quantity;
        System.out.printf("Total cost: Rs. %.2f%n", total);
        if (portfolio.buy(stock, quantity)) {
            transactions.add(new Transaction("BUY", symbol, quantity, stock.getPrice()));
            System.out.println("Purchase successful!");
        } else {
            System.out.println("Purchase failed. Please check your cash balance and quantity.");
        }
    }

    private static void sellStock() {
        portfolio.display(market);
        String symbol = readSymbol("Enter stock symbol to sell (e.g. TCS): ");
        Stock stock = market.get(symbol);
        if (stock == null) {
            System.out.println("Stock symbol not found.");
            return;
        }

        int quantity = readInt("Enter quantity: ");
        if (quantity <= 0) {
            System.out.println("Quantity must be greater than zero.");
            return;
        }

        if (portfolio.sell(stock, quantity)) {
            transactions.add(new Transaction("SELL", symbol, quantity, stock.getPrice()));
            System.out.printf("Sale successful. Amount received: Rs. %.2f%n", stock.getPrice() * quantity);
        } else {
            System.out.println("Sale failed. You do not own enough shares.");
        }
    }

    private static void displayTransactions() {
        System.out.println("\n============== TRANSACTION HISTORY ==============");
        if (transactions.isEmpty()) {
            System.out.println("No transactions yet.");
        } else {
            for (Transaction transaction : transactions) System.out.println(transaction);
        }
        System.out.println("=================================================");
    }

    private static String readSymbol(String prompt) {
        System.out.print(prompt);
        return scanner.nextLine().trim().toUpperCase();
    }

    private static int readInt(String prompt) {
        while (true) {
            System.out.print(prompt);
            String input = scanner.nextLine().trim();
            try {
                return Integer.parseInt(input);
            } catch (NumberFormatException ex) {
                System.out.println("Please enter a whole number.");
            }
        }
    }
}
